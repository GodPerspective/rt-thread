#ifndef __LINUX_MTD_COMPATMAC_H__
#define __LINUX_MTD_COMPATMAC_H__


#endif /* __LINUX_MTD_COMPATMAC_H__ */
