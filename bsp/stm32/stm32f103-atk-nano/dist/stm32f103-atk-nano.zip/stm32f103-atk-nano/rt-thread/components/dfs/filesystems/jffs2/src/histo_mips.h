#define BIT_DIVIDER_MIPS 1043 
static int bits_mips[8] = { 277,249,290,267,229,341,212,241}; /* mips32 */
